var names = {};

names.nameList = [
    "Xbots.io!",
    "Cheap!",
	"NOLAG!",


];

names.getRandomName = function() {
    return names.nameList[Math.floor((Math.random() * names.nameList.length))];
};

module.exports = names;
