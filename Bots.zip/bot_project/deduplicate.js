var fs = require('fs-extra');
var path = require('path');
extend = require("extend");
var fs = require('fs');
var lines = fs.readFileSync("proxy.txt").toString().split("\n");
    for (var i=0;i<lines.length;i++) {
    var proxy = lines[i];
	for (var j=0;j<lines.length;j++){
	var duplicate = lines[j];
	if(proxy===duplicate&&j!==i)lines[j]=null;
	}
	}
	var newlines="";
	for(var j=0;j<lines.length;j++){
	if(lines[j]!==null){
	newlines+=lines[j];
	newlines+="\n";
	}
	}
	fs.writeFileSync("proxy-deduplicated.txt",newlines);